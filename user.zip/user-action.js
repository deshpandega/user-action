// const getUsers = require('./actions/getUsers');
// const getUsersById = require('./actions/getUsersById');
// const putUsersById = require('./actions/putUsersById');
const postUser = require('./actions/postUser');
// const deleteUser = require('./actions/deleteUser');
const addPayment = require('./actions/addPaymentMethod');

// exports.getUsers = getUsers;
// exports.getUsersById = getUsersById;
// exports.putUsersById = putUsersById;
exports.postUser = postUser;
// exports.deleteUser = deleteUser;
exports.addPayment = addPayment;