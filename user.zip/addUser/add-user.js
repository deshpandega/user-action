const addUser = (params) => {

	//import statements to use multiple modules
  const jwt = require('jsonwebtoken');
  const bcrypt = require('bcryptjs');
  const mongoClient = require('mongodb').MongoClient;

  // Environment variable we are loading as params from config.json file
  const jwt_secret = params.jwt_secret;

  console.log("Here");

  const user = {
  	"name":"",
		"password" : "",
		"email" : "",
		"dob" : "",
		"aboutme" : "",
		"hobbies" : [
			{
				"name" : ""
			}
		],
		"registeredevents" : [
			{
				"name" : "",
				"venue" : ""
			}
		],
		"hostedevents" : [
			{
				"name" : "", 
				"venue" : ""
			}
		]
  };


}

exports.main = addUser;